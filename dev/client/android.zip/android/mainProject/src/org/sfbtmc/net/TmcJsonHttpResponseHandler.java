package org.sfbtmc.net;

import com.loopj.android.http.JsonHttpResponseHandler;

public class TmcJsonHttpResponseHandler extends JsonHttpResponseHandler {

}
