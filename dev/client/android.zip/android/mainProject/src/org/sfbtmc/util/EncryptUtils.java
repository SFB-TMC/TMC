package org.sfbtmc.util;

/**
 * Encryption
 * @author Administrator
 *
 */
public class EncryptUtils {

}
